package Scalarm::InformationService;

use 5.006;
use strict;
use warnings FATAL => 'all';

our $VERSION = '0.01';

sub function1 {
}

sub function2 {
}

1; # End of Scalarm::InformationService
